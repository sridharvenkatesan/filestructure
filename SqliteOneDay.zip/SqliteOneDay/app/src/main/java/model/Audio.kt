package model

class Audio {
    var audioTemplate: String = ""
    var audioUrl: String = ""
    var datePurchased: String = ""
    var identifier: String = ""
    var inAppPurchased: String = ""
    var promoCode: String = ""
    var audioTitle: String = ""
    var updatedAt: String = ""
}